<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/style.css"/>
    <title>Pro Rank</title>
</head>
<body>
  <header>
    <nav class="navbar">
      <button id="menuToggle"><image class="img_menu" src="assents/pro_rank_icon.png"></button>
      <ul id="menu">
        <li><a href="user_area.php">Inicio</a></li>
      </ul>
    </nav>
  </header>
										

<?php include 'header.php'; ?>
<h2>Está logado</h2>
<?php include 'footer.php'; ?>
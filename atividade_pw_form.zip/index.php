<?php include 'header.php'; ?>
  <h2> Quem somos? </h2>
<p>Somos uma plataforma de ranqueamemto de profissionais voltado a qualidade do serviço acima da qualificação, com a finalidade de promover os melhores profissionais por meio de ranks.</p>
<?php include 'footer.php'; ?>